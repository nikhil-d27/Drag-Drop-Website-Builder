import { closestCenter, DndContext } from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useState } from "react";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 0.5rem;
  height: 100vh;
  
  @media (min-width: 768px) {
    flex-direction: row;
  }
`;

const Panel = styled.div`
  background: white;
  padding: 0.75rem;
  border-radius: 0.25rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  width: 100%;
  
  @media (min-width: 768px) {
    width: ${props => props.type === 'sidebar' ? '200px' : '250px'};
  }
`;

const Canvas = styled.div`
  flex: 1;
  background: #f5f5f5;
  padding: 0.75rem;
  border-radius: 0.25rem;
  min-height: 300px;
  border: 2px dashed #ccc;
`;

const Button = styled.button`
  background: ${props => props.variant === 'delete' ? '#e74c3c' : props.variant === 'success' ? '#2ecc71' : '#4a90e2'};
  color: white;
  padding: 0.35rem 0.75rem;
  border-radius: 0.25rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 0.9rem;
  width: ${props => props.fullWidth ? '100%' : 'auto'};
  margin-bottom: ${props => props.fullWidth ? '0.35rem' : '0'};
  opacity: ${props => props.variant === 'delete' ? '0.7' : '1'};
  visibility: ${props => props.variant === 'delete' ? 'visible' : 'visible'};
  
  &:hover {
    background: ${props => props.variant === 'delete' ? '#c0392b' : props.variant === 'success' ? '#27ae60' : '#357abd'};
    opacity: 1;
  }
`;

const Input = styled.input`
  border: 1px solid #ddd;
  padding: 0.35rem;
  width: 100%;
  border-radius: 0.25rem;
  margin-bottom: 0.35rem;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #4a90e2;
    box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
  }
`;

const ElementWrapper = styled.div`
  position: relative;
  &:hover button { 
    opacity: 1;
    visibility: visible;
  }
`;

const availableElements = [
  { type: "text", label: "Text Block", icon: "📝" },
  { type: "image", label: "Image", icon: "🖼️" },
  { type: "button", label: "Button", icon: "🔘" },
  { type: "heading", label: "Heading", icon: "📌" },
  { type: "divider", label: "Divider", icon: "➖" },
  { type: "spacer", label: "Spacer", icon: "↕️" },
];

function DraggableElement({ id, element, onClick, selected, onDelete }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    border: selected ? '2px solid #4a90e2' : undefined,
    boxShadow: selected ? '0 0 0 2px #4a90e2' : undefined,
  };

  const renderElement = () => {
    const commonStyles = { margin: "0.5rem 0" };
    switch (element.type) {
      case "text":
        return <p style={{ ...commonStyles, fontSize: element.fontSize || "14px" }}>{element.content}</p>;
      case "image":
        return <img src={element.src} alt={element.alt || "img"} style={{ width: "100%", maxWidth: element.maxWidth || "100%" }} />;
      case "button":
        return (
          <button style={{
            ...commonStyles,
            backgroundColor: element.backgroundColor || "#4a90e2",
            color: element.textColor || "white",
            padding: "0.35rem 0.75rem",
            borderRadius: "0.25rem",
            border: "none",
            cursor: "pointer",
            fontSize: "0.9rem",
          }}>
            {element.label}
          </button>
        );
      case "heading":
        return <h2 style={{ ...commonStyles, fontSize: element.fontSize || "20px" }}>{element.content}</h2>;
      case "divider":
        return <hr style={{ border: "none", borderTop: "1px solid #ddd", margin: "0.5rem 0" }} />;
      case "spacer":
        return <div style={{ height: element.height || "15px" }} />;
      default:
        return null;
    }
  };

  return (
    <ElementWrapper>
      <div
        ref={setNodeRef}
        style={style}
        {...attributes}
        {...listeners}
        className={`p-3 border rounded-lg bg-white shadow-md mb-2 cursor-move hover:shadow-lg transition-shadow${selected ? ' selected-element' : ''}`}
        onClick={(e) => { e.stopPropagation(); onClick(id); }}
      >
        {renderElement()}
      </div>
      <Button
        variant="delete"
        style={{ 
          position: 'absolute', 
          top: 4, 
          right: 4, 
          padding: '2px 6px', 
          fontSize: '11px',
          zIndex: 1
        }}
        onClick={(e) => { e.stopPropagation(); onDelete(id); }}
      >
        Delete
      </Button>
    </ElementWrapper>
  );
}

export default function DragDropBuilder() {
  const [elements, setElements] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [counter, setCounter] = useState(1);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [previewDevice, setPreviewDevice] = useState('desktop');
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleDragEnd = (event) => {
    const { active, over } = event;
    if (active.id !== over?.id) {
      const oldIndex = elements.findIndex((el) => el.id === active.id);
      const newIndex = elements.findIndex((el) => el.id === over?.id);
      setElements((items) => arrayMove(items, oldIndex, newIndex));
    }
  };

  const handleAddElement = (type) => {
    const newId = `el-${counter}`;
    const newElement = {
      id: newId,
      type,
      ...(type === "text" && { content: "New Text", fontSize: "14px" }),
      ...(type === "image" && { src: "https://via.placeholder.com/150", alt: "Placeholder" }),
      ...(type === "button" && { label: "New Button", backgroundColor: "#4a90e2", textColor: "white" }),
      ...(type === "heading" && { content: "New Heading", fontSize: "20px" }),
      ...(type === "divider" && {}),
      ...(type === "spacer" && { height: "15px" }),
    };
    setElements([...elements, newElement]);
    setCounter(counter + 1);
    setSelectedId(newId);
  };

  const handleUpdate = (field, value) => {
    setElements((els) =>
      els.map((el) => (el.id === selectedId ? { ...el, [field]: value } : el))
    );
  };

  const handleDeleteElement = (id) => {
    setElements((els) => els.filter((el) => el.id !== id));
    if (selectedId === id) setSelectedId(null);
  };

  const selectedElement = elements.find((el) => el.id === selectedId);

  const renderPropertyPanel = () => {
    if (!selectedElement) return <p>Select an element to edit.</p>;

    switch (selectedElement.type) {
      case "text":
      case "heading":
        return (
          <>
            <Input
              value={selectedElement.content}
              onChange={(e) => handleUpdate("content", e.target.value)}
              placeholder="Edit text"
            />
            <Input
              type="number"
              value={selectedElement.fontSize?.replace("px", "")}
              onChange={(e) => handleUpdate("fontSize", `${e.target.value}px`)}
              placeholder="Font size (px)"
            />
          </>
        );
      case "image":
        return (
          <>
            <Input
              value={selectedElement.src}
              onChange={(e) => handleUpdate("src", e.target.value)}
              placeholder="Image URL"
            />
            <Input
              value={selectedElement.alt}
              onChange={(e) => handleUpdate("alt", e.target.value)}
              placeholder="Alt text"
            />
            <Input
              type="number"
              value={selectedElement.maxWidth?.replace("%", "")}
              onChange={(e) => handleUpdate("maxWidth", `${e.target.value}%`)}
              placeholder="Max width (%)"
            />
          </>
        );
      case "button":
        return (
          <>
            <Input
              value={selectedElement.label}
              onChange={(e) => handleUpdate("label", e.target.value)}
              placeholder="Button text"
            />
            <Input
              type="color"
              value={selectedElement.backgroundColor}
              onChange={(e) => handleUpdate("backgroundColor", e.target.value)}
            />
            <Input
              type="color"
              value={selectedElement.textColor}
              onChange={(e) => handleUpdate("textColor", e.target.value)}
            />
          </>
        );
      case "spacer":
        return (
          <Input
            type="number"
            value={selectedElement.height?.replace("px", "")}
            onChange={(e) => handleUpdate("height", `${e.target.value}px`)}
            placeholder="Height (px)"
          />
        );
      default:
        return null;
    }
  };

  const renderPreview = () => {
    const previewContent = (
      <div style={{
        background: 'white',
        padding: '1rem',
        borderRadius: '0.25rem',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        width: '100%',
        margin: '0 auto',
      }}>
        {elements.map((element) => (
          <div key={element.id} className="mb-4">
            {renderElement(element)}
          </div>
        ))}
      </div>
    );

    if (isFullscreen) {
      return (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'white',
          zIndex: 1000,
          padding: '2rem',
          overflowY: 'auto',
        }}>
          <Button
            variant="delete"
            style={{ position: 'fixed', top: '1rem', right: '1rem', zIndex: 1001 }}
            onClick={() => setIsFullscreen(false)}
          >
            Close Preview
          </Button>
          {previewContent}
        </div>
      );
    }

    return (
      <>
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem', justifyContent: 'center' }}>
          <Button
            variant="success"
            onClick={() => setIsFullscreen(true)}
          >
            Fullscreen Preview
          </Button>
        </div>
        {previewContent}
      </>
    );
  };

  const renderElement = (element) => {
    switch (element.type) {
      case 'text':
        return (
          <p style={{ 
            fontSize: element.fontSize || '14px',
            color: element.textColor || '#000',
            textAlign: element.textAlign || 'left',
            margin: '0.5rem 0'
          }}>
            {element.content || 'Text Element'}
          </p>
        );
      case 'heading':
        return (
          <h2 style={{ 
            fontSize: element.fontSize || '20px',
            color: element.textColor || '#000',
            textAlign: element.textAlign || 'left',
            margin: '0.5rem 0'
          }}>
            {element.content || 'Heading'}
          </h2>
        );
      case 'image':
        return (
          <img 
            src={element.src || 'https://via.placeholder.com/150'} 
            alt={element.alt || 'Image'}
            style={{ 
              width: element.maxWidth || '100%',
              height: 'auto',
              margin: '0.5rem 0'
            }}
          />
        );
      case 'button':
        return (
          <button style={{ 
            padding: element.padding || '8px 16px',
            backgroundColor: element.backgroundColor || '#4a90e2',
            color: element.textColor || '#fff',
            border: 'none',
            borderRadius: element.borderRadius || '4px',
            cursor: 'pointer',
            margin: '0.5rem 0'
          }}>
            {element.label || 'Button'}
          </button>
        );
      case 'divider':
        return <hr style={{ border: 'none', borderTop: '1px solid #ddd', margin: '0.5rem 0' }} />;
      case 'spacer':
        return <div style={{ height: element.height || '15px' }} />;
      default:
        return null;
    }
  };

  return (
    <Container>
      <Panel type="sidebar">
        <h2 style={{ fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '1rem' }}>Add Element</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
          {availableElements.map((el) => (
            <Button key={el.type} fullWidth onClick={() => handleAddElement(el.type)}>
              {el.icon} {el.label}
            </Button>
          ))}
        </div>
        <Button
          variant={isPreviewMode ? 'success' : 'delete'}
          fullWidth
          style={{ marginTop: '1rem' }}
          onClick={() => setIsPreviewMode(!isPreviewMode)}
        >
          {isPreviewMode ? "Exit Preview" : "Preview"}
        </Button>
      </Panel>

      <Canvas onClick={() => setSelectedId(null)}>
        {!isPreviewMode ? (
          <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={elements.map((el) => el.id)} strategy={verticalListSortingStrategy}>
              {elements.map((element) => (
                <DraggableElement
                  key={element.id}
                  id={element.id}
                  element={element}
                  onClick={setSelectedId}
                  selected={selectedId === element.id}
                  onDelete={handleDeleteElement}
                />
              ))}
            </SortableContext>
          </DndContext>
        ) : (
          renderPreview()
        )}
      </Canvas>

      <Panel type="property">
        <h2 style={{ fontSize: '1.1rem', fontWeight: 'bold', marginBottom: '1rem' }}>Edit Element</h2>
        {renderPropertyPanel()}
      </Panel>
    </Container>
  );
}


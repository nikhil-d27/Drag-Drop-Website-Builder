import React from 'react';
import { createGlobalStyle } from 'styled-components';
import DragDropBuilder from './DragDropBuilder';

const GlobalStyle = createGlobalStyle`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background-color: #f0f2f5;
  }
`;

export default function App() {
  return (
    <>
      <GlobalStyle />
      <DragDropBuilder />
    </>
  );
}